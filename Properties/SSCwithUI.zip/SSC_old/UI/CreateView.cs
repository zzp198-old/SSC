using Terraria.GameContent.UI.Elements;

namespace SSC.UI;

public class CreateView : UIPanel
{
    
}