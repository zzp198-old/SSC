using Terraria.GameContent.UI.Elements;
using Terraria.UI;

namespace SSC.UI;

public class LayoutView : UIState
{
    UIElement Container;
    ListView ListView;
    private UIScrollbar UIScrollbar;

    public override void OnInitialize()
    {
        Container = new UIElement();
        Container.Width.Set(600, 0);
        Container.Height.Set(600, 0);
        Container.HAlign = 0.5f;
        Container.VAlign = 0.5f;
        Append(Container);

        ListView = new ListView();
        ListView.Width.Set(400, 0);
        ListView.Height.Set(600, 0);
        ListView.HAlign = 0.5f;
        ListView.VAlign = 0.5f;
        Container.Append(ListView);
    }
}