using Terraria.GameContent.UI.Elements;
using Terraria.IO;


namespace SSC.UI;

public class ItemView : UIPanel
{
    public override void OnInitialize()
    {
    }
}