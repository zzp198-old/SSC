using Terraria;
using Terraria.GameContent.UI.Elements;

namespace SSC.UI;

public class ListView : UIPanel
{
    UIList UIList;
    UIScrollbar UIScrollbar;

    public override void OnInitialize()
    {
        UIList = new UIList();
        UIList.Width.Set(-10, 1);
        UIList.Height.Set(0, 1);
        Append(UIList);

        UIScrollbar = new UIScrollbar();
        UIScrollbar.Width.Set(20, 0);
        UIScrollbar.Height.Set(400, 0);
        UIScrollbar.Left.Set(-10, 1);
        UIList.SetScrollbar(UIScrollbar);
        UIList.Append(UIScrollbar);

        // var itemView = new ItemView(Main.PlayerList[0]);
    }
}